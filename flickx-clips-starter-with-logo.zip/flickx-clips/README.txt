# Flickx Clips setup

## Included
- `index.html` — public clip library with search, categories, preview and download
- `admin.html` — private login, upload, publish/hide and delete dashboard
- `setup.sql` — database, storage bucket and security policies
- `logo.svg` — Flickx Clips header logo
- `favicon.svg` — browser tab icon

## 1. Create the database and storage
1. Open your new Supabase project.
2. Go to SQL Editor → New query.
3. Paste all of `setup.sql` and run it.

## 2. Create your admin login
1. In Supabase open Authentication → Users.
2. Add a user with your own email and a strong password.
3. Copy the user's UUID from the Users table.
4. Open SQL Editor and run this, replacing the placeholder with the UUID:

```sql
insert into public.admin_users (user_id)
values ('PASTE-YOUR-AUTH-USER-UUID-HERE');
```

Only user IDs in `admin_users` can upload, publish, hide or delete clips. Do not add anyone else.

## 3. Publish the website
Upload `index.html`, `admin.html`, `logo.svg` and `favicon.svg` to the same folder on your static host (GitHub Pages, Netlify, Vercel, etc.). Open `index.html` for the public site and `admin.html` for your private dashboard.

The admin page is not protected just because its URL is hard to guess. The actual protection is Supabase Auth plus the database and Storage policies in `setup.sql`.

## 4. Upload clips
Open `admin.html`, sign in with the admin email/password you created, then upload a video. New uploads are published automatically. Use Hide to remove a clip from the public site without deleting it. Delete removes the database row and the stored files.

## Storage size note
The SQL creates a 50 MB per-file limit to work with the common Supabase Free plan limit. If your plan supports larger files, change `file_size_limit` in the bucket settings or SQL to the limit your plan allows. Large video uploads may need resumable uploads; this starter uses standard uploads.

## Security notes
- The publishable key is designed to be used in browser code. Never put a Supabase secret/service-role key in either HTML file.
- Public visitors can read published clip information and files in the public bucket. They cannot upload, update or delete.
- Keep your Supabase account password private and enable strong account security.
- Back up important source videos separately. A database is not a substitute for a backup.
