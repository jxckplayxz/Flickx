-- FLICKX CLIPS: run this entire file in Supabase SQL Editor.
-- This creates the public clip catalog, a public-read/private-write storage bucket,
-- and an admin allowlist. It does NOT create an admin account for you.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '' check (char_length(description) <= 500),
  category text not null default 'Clips' check (char_length(category) <= 35),
  video_path text not null unique,
  thumbnail_path text,
  is_published boolean not null default true,
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.videos enable row level security;

-- Admin verification helper. SECURITY DEFINER lets the policy check the allowlist
-- without granting users permission to add themselves to it.
create or replace function public.is_flickx_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.admin_users
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_flickx_admin() from public;
grant execute on function public.is_flickx_admin() to anon, authenticated;

-- Admins can verify their own allowlist entry. No client insert/update/delete policies.
drop policy if exists "Admins can read own admin entry" on public.admin_users;
create policy "Admins can read own admin entry"
on public.admin_users for select
to authenticated
using (user_id = (select auth.uid()));

-- Public visitors can only read published video metadata.
drop policy if exists "Anyone can view published videos" on public.videos;
create policy "Anyone can view published videos"
on public.videos for select
to anon, authenticated
using (is_published = true);

-- Admins can manage every video record.
drop policy if exists "Admins can manage videos" on public.videos;
create policy "Admins can manage videos"
on public.videos for all
to authenticated
using (public.is_flickx_admin())
with check (public.is_flickx_admin());

-- Create a public bucket so visitors can preview and download uploaded clips.
-- Public read access does not grant upload, update or delete access.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'flickx-videos',
  'flickx-videos',
  true,
  52428800,
  array['video/mp4','video/webm','video/quicktime','image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Only allowlisted admins can upload, replace or delete files in this bucket.
drop policy if exists "Admins can upload Flickx files" on storage.objects;
create policy "Admins can upload Flickx files"
on storage.objects for insert
to authenticated
with check (bucket_id = 'flickx-videos' and public.is_flickx_admin());

drop policy if exists "Admins can update Flickx files" on storage.objects;
create policy "Admins can update Flickx files"
on storage.objects for update
to authenticated
using (bucket_id = 'flickx-videos' and public.is_flickx_admin())
with check (bucket_id = 'flickx-videos' and public.is_flickx_admin());

drop policy if exists "Admins can delete Flickx files" on storage.objects;
create policy "Admins can delete Flickx files"
on storage.objects for delete
to authenticated
using (bucket_id = 'flickx-videos' and public.is_flickx_admin());

-- IMPORTANT: after creating your admin user in Authentication > Users,
-- copy that user's UUID and run this separately, replacing the placeholder:
-- insert into public.admin_users (user_id)
-- values ('PASTE-YOUR-AUTH-USER-UUID-HERE');
